//
//  GrocerySections.swift
//  Vanama_GroceryApp
//
//  Created by student on 4/11/22.
//

import Foundation

struct GrocerySections{
    var section = ""
    var items_Array : [GroceryItem] = []
}

struct GroceryItem{
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}


let grocery1 = GrocerySections(section: "Frozen Food", items_Array: [
    GroceryItem(itemName:"Shrimp", itemImage: "shrimp", itemInfo: "King Prawns marinated with chili powder, turmeric, salt, lime juice, ginger, garlic and fried. Garnished with corriander leaves"),
    GroceryItem(itemName:"Ice-cream", itemImage: "icecream", itemInfo: "Ice cream is a sweetened frozen food typically eaten as a snack or dessert. It may be made from milk or cream and is flavoured with a sweetener, either sugar or an alternative, and a spice, such as cocoa or vanilla, or with fruit such as strawberries or peaches. "),
    GroceryItem(itemName:"Frozen Yogurt", itemImage: "yogurt", itemInfo: " yogurt, less commonly yoghourt or yogourt, is a dairy product produced by bacterial fermentation of milk. Any sort of milk may be used to make yoghurt, but modern production is dominated by cow's milk."),
    GroceryItem(itemName:"Vegetable Pizza", itemImage: "pizza", itemInfo: "Pizza is a savory dish of Italian origin, consisting of a usually round, flattened base of leavened wheat-based dough topped with tomatoes, cheese, and often various other ingredients."),
    GroceryItem(itemName:"Frozen Peas", itemImage: "peas", itemInfo: "The pea is most commonly the small spherical seed or the seed-pod of the pod fruit Pisum sativum. Each pod contains several peas, which can be green or yellow. ")
])

let grocery2 = GrocerySections(section: "Produce", items_Array: [
    GroceryItem(itemName:"Bananas", itemImage: "banana", itemInfo: "The term banana is also used as the common name for the plants that produce the fruit. This can extend to other members of the genus Musa, such as the scarlet banana (Musa coccinea), the pink banana (Musa velutina), and the Fe'i bananas."),
    GroceryItem(itemName:"Apples", itemImage: "apple", itemInfo: "Apple was better than any other name they could think of. We both tried to come up with technical-sounding names that were better, but we couldn't think of any good ones."),
    GroceryItem(itemName:"Oranges", itemImage: "orange", itemInfo: "The orange originated in a region encompassing Southern China, Northeast India, and Myanmar, and the earliest mention of the sweet orange was in Chinese literature in 314 BC. As of 1987, orange trees were found to be the most cultivated fruit tree in the world."),
    GroceryItem(itemName:"Mangoes", itemImage: "mango", itemInfo: "It is named after the town of Banganapalle in Andhra Pradesh. Indian Mangoes are also abundant in the Philippines especially during the summer months. This variety of mango is smaller, pudgier and is enjoyable to eat because it is not very sour. It is also sweet when ripe."),
    GroceryItem(itemName:"Strawberries", itemImage: "strawberry", itemInfo: "The first garden strawberry was grown in Brittany, France, during the late 18th century.Prior to this, wild strawberries and cultivated selections from wild strawberry species were the common source of the fruit.")
])

let grocery3 = GrocerySections(section: "Meat and SeaFood", items_Array: [
    GroceryItem(itemName:"Chicken", itemImage: "chicken", itemInfo: "Chicken curry is a dish originating from the Indian subcontinent. It is common in the Indian subcontinent, Southeast Asia, Great Britain, and the Caribbean. A typical curry from the Indian subcontinent consists of chicken stewed in an onion- and tomato-based sauce."),
    GroceryItem(itemName:"Salmon", itemImage: "salmon", itemInfo: "Salmon flesh is generally orange to red, although there are some examples of white-fleshed wild salmon. The natural color of salmon results from carotenoid pigments, largely astaxanthin and canthaxanthin in the flesh."),
    GroceryItem(itemName:"Roast Beef", itemImage: "beaf", itemInfo: "Roast beef is a dish of beef that is roasted, generally served as the main dish of a meal. In the Anglosphere, roast beef is one of the meats often served at Sunday lunch or dinner. Yorkshire pudding is a standard side dish. "),
    GroceryItem(itemName:"Trout", itemImage: "trout", itemInfo: "Trout are species of freshwater fish belonging to the genera Oncorhynchus, Salmo and Salvelinus, all of the subfamily Salmoninae of the family Salmonidae."),
    GroceryItem(itemName:"Crab", itemImage: "crab", itemInfo: "The main ingredient in imitation crab is surimi, which is typically mixed with water, starch, sugar, egg whites, vegetable oil, salt and additives.")
])

let grocery4 = GrocerySections(section: "Oils and Sauces", items_Array: [
    GroceryItem(itemName:"Tomato Sauce", itemImage: "tsauce", itemInfo: "A simple tomato sauce consists of chopped tomatoes sautéed in olive oil and simmered until they lose their raw flavor, seasoned to taste with salt, or other herbs or spices."),
    GroceryItem(itemName:"Hot Pepper Sauce", itemImage: "hotSauce", itemInfo: "Hot sauce is a type of condiment, seasoning, or salsa made from chili peppers and other ingredients. Many commercial varieties of mass-produced hot sauce exist."),
    GroceryItem(itemName:"Barbecue Sauce", itemImage: "bbqSauce", itemInfo: "Barbecue sauce (also abbreviated as BBQ sauce) is a sauce used as a marinade, basting, condiment, or topping for meat cooked in the barbecue cooking style, including pork or beef ribs and chicken."),
    GroceryItem(itemName:"Red-Wine vinegar", itemImage: "redwine", itemInfo: "Vinegar is an aqueous solution of acetic acid and trace compounds that may include flavorings. Vinegar typically contains 5–8% acetic acid by volume."),
    GroceryItem(itemName:"Canola Oil", itemImage: "oil", itemInfo: "Canola oil is a vegetable oil derived from a variety of rapeseed that is low in erucic acid, as opposed to colza oil. There are both edible and industrial forms produced from the seed of any of several cultivars of the plant family Brassicaceae.")
])


let allGroceries = [grocery1, grocery2, grocery3, grocery4]

let grocery = [grocery1.section, grocery2.section, grocery3.section, grocery4.section]

let acc = [grocery1.items_Array[0].itemName,]

