//
//  GrocerySectionsViewController.swift
//  Vanama_GroceryApp
//
//  Created by student on 4/11/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController {
    
    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    var gryArray = grocery
    var itemsArray = GrocerySections()
    
    var itemsss = GroceryItem()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemsSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            
            destination.label = "\(gryArray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!])"
            //destination.itemsView = itemsArray
            
            //[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
            
            destination.itemsView = allGroceries[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
            
        }
    }
    
}
extension GrocerySectionsViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gryArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        cell.textLabel?.text = gryArray[indexPath.row]
        
        return cell
    }
    
    
}

