//
//  ItemInfoViewController.swift
//  Vanama_GroceryApp
//
//  Created by student on 4/11/22.
//

import UIKit

class ItemInfoViewController: UIViewController {
    
    var eachItem = GroceryItem()

    @IBOutlet weak var labelOutlet2: UILabel!
    
    
    @IBOutlet weak var viewOutlet: UIButton!
    
    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var itemInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        animateImage()
        itemInfoOutlet.text = ""
        labelOutlet2.text = eachItem.itemName
        
        self.labelOutlet2.center.x = self.view.center.x - 60
        UIView.animate(withDuration: 1.5,animations: {
            self.labelOutlet2.center.x = self.view.center.x
        })
        
        self.itemImageViewOutlet.center.x = self.view.center.x - 60
        UIView.animate(withDuration: 2,animations: {
        self.itemImageViewOutlet.center.x = self.view.center.x
        })
        
        self.viewOutlet.center.x = self.view.center.x - 60
        UIView.animate(withDuration: 2.5 ,animations: {
        self.viewOutlet.center.x = self.view.center.x
        })
        
    }
//    override func viewDidAppear(_ animated: Bool) {
//        itemImageViewOutlet.frame.origin.x = view.frame.maxX
//    }
    
    
    @IBAction func showItemInfoAction(_ sender: UIButton) {
        self.itemInfoOutlet.center.x = self.view.center.x - 60
        itemInfoOutlet.text = eachItem.itemInfo
        UIView.animate(withDuration: 1,animations: {
        self.itemInfoOutlet.center.x = self.view.center.x - 10
        })
        
        UIView.animate(withDuration: 1, animations: {
            self.itemInfoOutlet.alpha = 0
        })
        
        UIView.animate(withDuration: 1, delay: 0.4,animations: { [self] in
            self.itemInfoOutlet.alpha = 1
        })
        
    }
    
    func animateImage()
    {
        UIView.animate(withDuration: 1, animations: {
            self.itemImageViewOutlet.alpha = 0
            self.labelOutlet2.alpha = 0
            self.viewOutlet.alpha = 0
        })
        
        UIView.animate(withDuration: 1, delay: 0.4,animations: { [self] in
            self.itemImageViewOutlet.alpha = 1
            self.labelOutlet2.alpha = 1
            self.viewOutlet.alpha = 1
            self.itemImageViewOutlet.image = UIImage(named: self.eachItem.itemImage)
        })
    }
    


}
